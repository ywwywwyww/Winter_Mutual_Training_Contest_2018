#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<ctime>
#include<utility>
#include<cmath>
#include<functional>
#include<windows.h>
using namespace std;
typedef double db;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
void sort(int &a,int &b)
{
	if(a>b)
		swap(a,b);
}
void open(const char *s)
{
#ifndef ONLINE_JUDGE
	char str[100];
	sprintf(str,"%s.in",s);
	freopen(str,"r",stdin);
	sprintf(str,"%s.out",s);
	freopen(str,"w",stdout);
#endif
}
int rd()
{
	int s=0,c,b=0;
	while(((c=getchar())<'0'||c>'9')&&c!='-');
	if(c=='-')
	{
		c=getchar();
		b=1;
	}
	do
	{
		s=s*10+c-'0';
	}
	while((c=getchar())>='0'&&c<='9');
	return b?-s:s;
}
void put(int x)
{
	if(!x)
	{
		putchar('0');
		return;
	}
	static int c[20];
	int t=0;
	while(x)
	{
		c[++t]=x%10;
		x/=10;
	}
	while(t)
		putchar(c[t--]+'0');
}
int upmin(int &a,int b)
{
	if(b<a)
	{
		a=b;
		return 1;
	}
	return 0;
}
int upmax(int &a,int b)
{
	if(b>a)
	{
		a=b;
		return 1;
	}
	return 0;
}
int a[30][30];
int lx[100010];
int ly[100010];
int n;
ll m;
int t;
int k;
void gao1()
{
}
void gao2()
{
	for(int i=1;i<=n*n/5;i++)
	{
		int x,y;
		do
		{
			x=rand()%n+1;
			y=rand()%n+1;
			if(x>y)
				swap(x,y);
		}
		while(x==y||a[x][y]);
		a[x][y]=1;
		t++;
		lx[t]=x;
		ly[t]=y;
	}
}
void gao3()
{
	for(int i=1;i<=n*n/5;i++)
	{
		int x,y;
		do
		{
			x=rand()%n+1;
			y=rand()%n+1;
			if(x>y)
				swap(x,y);
		}
		while(x==y||a[x][y]);
		a[x][y]=1;
		t++;
		lx[t]=x;
		ly[t]=y;
	}
	int y=min(n/2,rand()%5+1);
	for(int i=1;i<=y;i++)
	{
		int x,y;
		do
		{
			x=rand()%n+1;
			y=rand()%n+1;
		}
		while(x==y||a[x][y]);
		a[x][y]=1;
		t++;
		lx[t]=x;
		ly[t]=y;
	}
}
void gao4()
{
	for(int i=1;i<=n*n/5;i++)
	{
		int x,y;
		do
		{
			x=rand()%n+1;
			y=rand()%n+1;
			if(x>y)
				swap(x,y);
		}
		while(x==y||a[x][y]);
		a[x][y]=1;
		t++;
		lx[t]=x;
		ly[t]=y;
	}
}
void gao5()
{
	for(int i=1;i<=n/4;i++)
	{
		int x,y;
		do
		{
			x=rand()%n+1;
			y=rand()%n+1;
		}
		while(x==y||a[x][y]);
		a[x][y]=1;
		t++;
		lx[t]=x;
		ly[t]=y;
	}
}
void gao6()
{
	for(int i=1;i<=n*(n-1)/2;i++)
	{
		int x,y;
		do
		{
			x=rand()%n+1;
			y=rand()%n+1;
		}
		while(x==y||a[x][y]);
		a[x][y]=1;
		t++;
		lx[t]=x;
		ly[t]=y;
	}
}
void gao7()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(j!=i)
			{
				t++;
				lx[t]=i;
				ly[t]=j;
			}
}
void gao8()
{
	for(int i=1;i<=n;i++)
	{
		int x,y;
		do
		{
			x=rand()%n+1;
			y=rand()%n+1;
		}
		while(x==y||a[x][y]);
		a[x][y]=1;
		t++;
		lx[t]=x;
		ly[t]=y;
	}
}
int main(int argc,char **argv)
{
	sscanf(argv[1],"%d",&k);
	srand(time(0));
	if(k<=10)
	{
		n=5;
		m=10;
	}
	else if(k<=20)
	{
		n=13;
		m=13;
	}
	else if(k<=30)
	{
		n=20;
		m=10000000;
	}
	else
	{
		n=20;
		m=10000000000ll;
	}
	if(k%10)
	{
		n-=rand()&1;
		m*=1-(db)rand()/RAND_MAX*0.1;
		m=max(m,1ll);
	}
	if(k>=31&&k<=40)
		gao1();
	else
	{
		if(k%10==1)
			gao1();
		else if(k%10==2)
			gao2();
		else if(k%10==3)
			gao3();
		else if(k%10==4)
			gao4();
		else if(k%10==5)
			gao5();
		else if(k%10==6)
			gao6();
		else if(k%10==7)
			gao7();
		else
			gao8();
	}
	printf("%d %lld %d\n",n,m,t);
	for(int i=1;i<=t;i++)
		printf("%d %d\n",lx[i],ly[i]);
	Sleep(1200);
	return 0;
}
