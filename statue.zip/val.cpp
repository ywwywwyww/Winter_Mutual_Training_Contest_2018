#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<ctime>
#include<functional>
#include<cmath>
#include<vector>
#include<assert.h>
#include"testlib.h"
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef double db;
typedef std::pair<int,int> pii;
typedef std::pair<ll,ll> pll;
void open(const char *s){
#ifndef ONLINE_JUDGE
	char str[100];sprintf(str,"%s.in",s);freopen(str,"r",stdin);sprintf(str,"%s.out",s);freopen(str,"w",stdout);
#endif
}
void open2(const char *s){
#ifdef DEBUG
	char str[100];sprintf(str,"%s.in",s);freopen(str,"r",stdin);sprintf(str,"%s.out",s);freopen(str,"w",stdout);
#endif
}
int rd(){int s=0,c,b=0;while(((c=getchar())<'0'||c>'9')&&c!='-');if(c=='-'){c=getchar();b=1;}do{s=s*10+c-'0';}while((c=getchar())>='0'&&c<='9');return b?-s:s;}
void put(int x){if(!x){putchar('0');return;}static int c[20];int t=0;while(x){c[++t]=x%10;x/=10;}while(t)putchar(c[t--]+'0');}
int upmin(int &a,int b){if(b<a){a=b;return 1;}return 0;}
int upmax(int &a,int b){if(b>a){a=b;return 1;}return 0;}
int a[50][50];
int main()
{
	registerValidation();
	inf.strict=0;
	int n=inf.readInt(1,20,"n");
	ll m=inf.readLong(1,10000000000ll,"m");
	int k=inf.readInt(0,n*(n-1),"k");
	inf.readEoln();
	for(int i=1;i<=k;i++)
	{
		int x=inf.readInt(1,n,"x_i");
		int y=inf.readInt(1,n,"y_i");
		ensuref(x!=y,"x_i can't be equal to y_i");
		ensuref(!a[x][y],"there are two identical curses");
		a[x][y]=1;
		inf.readEoln();
	}
	inf.readEof();
	return 0;
}
